Adresár na vloženie súborov (upload)

- Vlož sem súbory, ktoré chceš dočasne preniesť do projektu (napr. .env, exporty, dočasné dáta).
- Tento adresár je štandardne ignorovaný Gitom (okrem tohto README a .gitignore), takže citlivé súbory sa necommitnú.
- Cesta k adresáru:
  /workspaces/narbon-jan-HP/pc/PC/OpenAIGPT/SaxoAPI/Testovanie/vklad

Pozn.: Ak budeš chcieť niektoré súbory predsa len commitnúť, úpravu .gitignore sprav opatrne.
